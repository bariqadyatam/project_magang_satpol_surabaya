<?php
session_start();
session_destroy();
header("location:index.php?value=94ec4siq26kjm2b3l6sfsqtm41");
exit;
?>